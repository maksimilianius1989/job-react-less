import React, {useState} from 'react';
import logo from './logo.svg';
import './App.css';
import {TaskList} from './init/taskList'

const App = () => {
	return (
		<div className="container">
			<h2>Test</h2>
			<List/>
		</div>
	);
};

const List = () => {

	// const listTask = TaskList.map(function (task, index) {
	// 	return (
	// 		<Fragment key={ task.id }>
	// 			<p>hello</p>
	// 			<Task  task={task} />
	// 		</Fragment>
	// 		)
	// });
	// const listTask = TaskList.map((task, index) => {
	// 	return <Task key={index} task={task}/>
	// });
	const listTask = TaskList.map(task => <Task key={task.id} task={task}/> );


	return (
		<>
			<h2>MY Task List </h2>
			<ul className="collection" >{listTask}</ul>
		</>
	)
};

const Task = (props) => {
	const {task} = props;
	const [count, setCount] = useState(0);
	const handleClick = () => setCount(count+1);
	return (
		<li className="collection-item" onClick={handleClick}>Click : {count} | {task.title}</li>
	)
};

export default App;
